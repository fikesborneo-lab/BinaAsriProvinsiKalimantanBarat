/**
 * =====================================================
 * YAYASAN BINA ASRI PROVINSI KALIMANTAN BARAT
 * Google Apps Script Backend & Admin Management System
 * =====================================================
 */

const SPREADSHEET_ID = '1MSV2TjKQ6lRkjWOXqV7VuzY4KUG4wj3K0trlnLmYaV8';
const LOGO_BULAT    = 'https://lh3.googleusercontent.com/d/1t_el0P4aHM3gLG4RTDrupVAjYTIaMqMZ';
const LOGO_PERSEGI  = 'https://lh3.googleusercontent.com/d/1BX2QKAod3qOttaebEYTlW61Mx4L5__5Q';

/**
 * Menyajikan halaman web utama
 */
function doGet(e) {
  const template = HtmlService.createTemplateFromFile('Index');
  
  // Ambil data untuk initial render
  template.kontenWeb = getKontenWeb();
  template.berita = getBerita();
  template.program = getProgram();
  template.galeri = getGaleri();
  template.pengurus = getPengurus();
  template.logoBulat = LOGO_BULAT;
  template.logoPersegi = LOGO_PERSEGI;
  
  return template.evaluate()
    .setTitle('Yayasan Bina Asri - Kalimantan Barat')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1.0, maximum-scale=5.0')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * Mendapatkan objek sheet dengan auto-create jika belum ada
 */
function getSheet(sheetName) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
  }
  return sheet;
}

/**
 * Format tanggal Indonesia ramah pengguna
 */
function formatTanggal(tgl) {
  if (!tgl) return '';
  try {
    const d = new Date(tgl);
    if (isNaN(d.getTime())) return tgl.toString();
    const bulan = ['Januari','Februari','Maret','April','Mei','Juni',
                   'Juli','Agustus','September','Oktober','November','Desember'];
    return d.getDate() + ' ' + bulan[d.getMonth()] + ' ' + d.getFullYear();
  } catch (e) {
    return tgl.toString();
  }
}

/**
 * Mendapatkan ID berikutnya untuk suatu sheet (Auto Increment)
 */
function getNextId(sheet) {
  const data = sheet.getDataRange().getValues();
  if (data.length <= 1) return 1;
  let maxId = 0;
  for (let i = 1; i < data.length; i++) {
    const val = Number(data[i][0]);
    if (!isNaN(val) && val > maxId) {
      maxId = val;
    }
  }
  return maxId + 1;
}

/**
 * =====================================================
 * PUBLIC DATA API
 * =====================================================
 */

function getBerita() {
  try {
    const sheet = getSheet('Berita');
    const data = sheet.getDataRange().getValues();
    if (data.length <= 1) return [];
    const result = [];
    for (let i = 1; i < data.length; i++) {
      if (!data[i][0] && !data[i][1]) continue;
      result.push({
        id: data[i][0],
        judul: data[i][1] || '',
        tanggal: formatTanggal(data[i][2]),
        rawTanggal: data[i][2] ? Utilities.formatDate(new Date(data[i][2]), Session.getScriptTimeZone() || 'Asia/Jakarta', 'yyyy-MM-dd') : '',
        kategori: data[i][3] || 'Umum',
        ringkasan: data[i][4] || '',
        konten: data[i][5] || '',
        gambar: data[i][6] || LOGO_BULAT
      });
    }
    return result.reverse();
  } catch (err) {
    Logger.log('Error getBerita: ' + err);
    return [];
  }
}

function getProgram() {
  try {
    const sheet = getSheet('Program');
    const data = sheet.getDataRange().getValues();
    if (data.length <= 1) return [];
    const result = [];
    for (let i = 1; i < data.length; i++) {
      if (!data[i][0] && !data[i][1]) continue;
      result.push({
        id: data[i][0],
        nama: data[i][1] || '',
        deskripsi: data[i][2] || '',
        target: data[i][3] || '',
        progress: Number(data[i][4]) || 0
      });
    }
    return result;
  } catch (err) {
    Logger.log('Error getProgram: ' + err);
    return [];
  }
}

function getGaleri() {
  try {
    const sheet = getSheet('Galeri');
    const data = sheet.getDataRange().getValues();
    if (data.length <= 1) return [];
    const result = [];
    for (let i = 1; i < data.length; i++) {
      if (!data[i][0] && !data[i][1]) continue;
      result.push({
        id: data[i][0],
        judul: data[i][1] || '',
        gambar: data[i][2] || LOGO_BULAT
      });
    }
    return result.reverse();
  } catch (err) {
    Logger.log('Error getGaleri: ' + err);
    return [];
  }
}

function getPengurus() {
  try {
    const sheet = getSheet('Pengurus');
    const data = sheet.getDataRange().getValues();
    if (data.length <= 1) return [];
    const result = [];
    for (let i = 1; i < data.length; i++) {
      if (!data[i][0] && !data[i][1]) continue;
      result.push({
        id: data[i][0],
        nama: data[i][1] || '',
        jabatan: data[i][2] || '',
        foto: data[i][3] || LOGO_BULAT
      });
    }
    return result;
  } catch (err) {
    Logger.log('Error getPengurus: ' + err);
    return [];
  }
}

/**
 * Simpan pesan dari formulir kontak publik
 */
function simpanPesan(formData) {
  try {
    const sheet = getSheet('Pesan');
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(['Timestamp','Nama','Email','Telepon','Subjek','Pesan']);
      sheet.getRange(1, 1, 1, 6)
        .setFontWeight('bold')
        .setBackground('#2E7D32')
        .setFontColor('#FFFFFF');
    }
    const timestamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Jakarta', 'yyyy-MM-dd HH:mm:ss');
    sheet.appendRow([
      timestamp,
      formData.nama || '',
      formData.email || '',
      formData.telepon || '',
      formData.subjek || '',
      formData.pesan || ''
    ]);
    return { success: true, message: 'Pesan Anda telah berhasil dikirim ke Yayasan Bina Asri. Terima kasih!' };
  } catch (err) {
    Logger.log('Error simpanPesan: ' + err);
    return { success: false, message: 'Gagal mengirim pesan: ' + err.toString() };
  }
}

/**
 * =====================================================
 * SISTEM ADMIN: AUTH & CRUD MANAGEMENT
 * =====================================================
 */

/**
 * Ambil atau inisialisasi sheet Admin
 */
function getAdminSheet() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  let sheet = ss.getSheetByName('Admin');
  if (!sheet) {
    sheet = ss.insertSheet('Admin');
  }
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(['Username', 'Password', 'Nama', 'Role', 'TerakhirLogin']);
    sheet.getRange(1, 1, 1, 5)
      .setFontWeight('bold')
      .setBackground('#1B5E20')
      .setFontColor('#FFFFFF');
    // Akun default admin
    sheet.appendRow(['admin', 'admin123', 'Pengurus Bina Asri', 'Superadmin', '']);
  }
  return sheet;
}

/**
 * Verifikasi login admin
 */
function loginAdmin(username, password) {
  try {
    const sheet = getAdminSheet();
    const data = sheet.getDataRange().getValues();
    if (data.length <= 1) {
      return { success: false, message: 'Akun admin belum dikonfigurasi di spreadsheet.' };
    }

    const inputUser = (username || '').trim().toLowerCase();
    const inputPass = (password || '').trim();

    for (let i = 1; i < data.length; i++) {
      const dbUser = (data[i][0] || '').toString().trim().toLowerCase();
      const dbPass = (data[i][1] || '').toString().trim();
      
      if (inputUser === dbUser && inputPass === dbPass) {
        // Catat timestamp login
        const nowStr = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Asia/Jakarta', 'yyyy-MM-dd HH:mm:ss');
        sheet.getRange(i + 1, 5).setValue(nowStr);

        const token = Utilities.base64Encode(inputUser + ':' + new Date().getTime());
        return {
          success: true,
          message: 'Login berhasil! Selamat datang di Sistem Admin Yayasan Bina Asri.',
          user: {
            username: data[i][0],
            nama: data[i][2] || 'Admin',
            role: data[i][3] || 'Administrator'
          },
          token: token
        };
      }
    }
    return { success: false, message: 'Username atau Password salah. Silakan periksa kembali.' };
  } catch (err) {
    Logger.log('Error loginAdmin: ' + err);
    return { success: false, message: 'Terjadi kesalahan sistem saat login: ' + err.toString() };
  }
}

/**
 * Ganti password akun admin
 */
function gantiPasswordAdmin(username, oldPassword, newPassword) {
  try {
    const sheet = getAdminSheet();
    const data = sheet.getDataRange().getValues();
    const inputUser = (username || '').trim().toLowerCase();
    const inputOld = (oldPassword || '').trim();
    const inputNew = (newPassword || '').trim();

    if (!inputNew || inputNew.length < 5) {
      return { success: false, message: 'Password baru minimal harus 5 karakter!' };
    }

    for (let i = 1; i < data.length; i++) {
      const dbUser = (data[i][0] || '').toString().trim().toLowerCase();
      const dbPass = (data[i][1] || '').toString().trim();

      if (inputUser === dbUser && inputOld === dbPass) {
        sheet.getRange(i + 1, 2).setValue(inputNew);
        return { success: true, message: 'Password berhasil diperbarui!' };
      }
    }
    return { success: false, message: 'Password lama Anda tidak sesuai!' };
  } catch (err) {
    Logger.log('Error gantiPasswordAdmin: ' + err);
    return { success: false, message: 'Gagal memperbarui password: ' + err.toString() };
  }
}

/**
 * Kelola Berita: Tambah / Edit / Hapus
 */
function simpanBerita(item) {
  try {
    const sheet = getSheet('Berita');
    const isEdit = item.id ? true : false;
    const tanggal = item.tanggal ? new Date(item.tanggal) : new Date();

    if (isEdit) {
      const data = sheet.getDataRange().getValues();
      for (let i = 1; i < data.length; i++) {
        if (data[i][0] == item.id) {
          const row = i + 1;
          sheet.getRange(row, 2).setValue(item.judul || '');
          if (item.tanggal) sheet.getRange(row, 3).setValue(tanggal);
          sheet.getRange(row, 4).setValue(item.kategori || 'Umum');
          sheet.getRange(row, 5).setValue(item.ringkasan || '');
          sheet.getRange(row, 6).setValue(item.konten || '');
          sheet.getRange(row, 7).setValue(item.gambar || LOGO_BULAT);
          return { success: true, message: 'Berita berhasil diperbarui!' };
        }
      }
      return { success: false, message: 'ID Berita tidak ditemukan.' };
    } else {
      const newId = getNextId(sheet);
      sheet.appendRow([
        newId,
        item.judul || '',
        tanggal,
        item.kategori || 'Umum',
        item.ringkasan || '',
        item.konten || '',
        item.gambar || LOGO_BULAT
      ]);
      return { success: true, message: 'Berita baru berhasil ditambahkan!' };
    }
  } catch (err) {
    Logger.log('Error simpanBerita: ' + err);
    return { success: false, message: 'Gagal menyimpan berita: ' + err.toString() };
  }
}

function hapusBerita(id) {
  try {
    const sheet = getSheet('Berita');
    const data = sheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (data[i][0] == id) {
        sheet.deleteRow(i + 1);
        return { success: true, message: 'Berita berhasil dihapus!' };
      }
    }
    return { success: false, message: 'ID Berita tidak ditemukan.' };
  } catch (err) {
    Logger.log('Error hapusBerita: ' + err);
    return { success: false, message: 'Gagal menghapus berita: ' + err.toString() };
  }
}

/**
 * Kelola Program: Tambah / Edit / Hapus
 */
function simpanProgram(item) {
  try {
    const sheet = getSheet('Program');
    const isEdit = item.id ? true : false;
    const progress = Math.min(100, Math.max(0, Number(item.progress) || 0));

    if (isEdit) {
      const data = sheet.getDataRange().getValues();
      for (let i = 1; i < data.length; i++) {
        if (data[i][0] == item.id) {
          const row = i + 1;
          sheet.getRange(row, 2).setValue(item.nama || '');
          sheet.getRange(row, 3).setValue(item.deskripsi || '');
          sheet.getRange(row, 4).setValue(item.target || '');
          sheet.getRange(row, 5).setValue(progress);
          return { success: true, message: 'Program berhasil diperbarui!' };
        }
      }
      return { success: false, message: 'ID Program tidak ditemukan.' };
    } else {
      const newId = getNextId(sheet);
      sheet.appendRow([
        newId,
        item.nama || '',
        item.deskripsi || '',
        item.target || '',
        progress
      ]);
      return { success: true, message: 'Program baru berhasil ditambahkan!' };
    }
  } catch (err) {
    Logger.log('Error simpanProgram: ' + err);
    return { success: false, message: 'Gagal menyimpan program: ' + err.toString() };
  }
}

function hapusProgram(id) {
  try {
    const sheet = getSheet('Program');
    const data = sheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (data[i][0] == id) {
        sheet.deleteRow(i + 1);
        return { success: true, message: 'Program berhasil dihapus!' };
      }
    }
    return { success: false, message: 'ID Program tidak ditemukan.' };
  } catch (err) {
    Logger.log('Error hapusProgram: ' + err);
    return { success: false, message: 'Gagal menghapus program: ' + err.toString() };
  }
}

/**
 * Kelola Galeri: Tambah / Hapus
 */
function simpanGaleri(item) {
  try {
    const sheet = getSheet('Galeri');
    const newId = getNextId(sheet);
    sheet.appendRow([
      newId,
      item.judul || 'Dokumentasi Yayasan',
      item.gambar || LOGO_BULAT
    ]);
    return { success: true, message: 'Foto galeri berhasil ditambahkan!' };
  } catch (err) {
    Logger.log('Error simpanGaleri: ' + err);
    return { success: false, message: 'Gagal menyimpan galeri: ' + err.toString() };
  }
}

function hapusGaleri(id) {
  try {
    const sheet = getSheet('Galeri');
    const data = sheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (data[i][0] == id) {
        sheet.deleteRow(i + 1);
        return { success: true, message: 'Foto galeri berhasil dihapus!' };
      }
    }
    return { success: false, message: 'ID Foto tidak ditemukan.' };
  } catch (err) {
    Logger.log('Error hapusGaleri: ' + err);
    return { success: false, message: 'Gagal menghapus foto galeri: ' + err.toString() };
  }
}

/**
 * Kelola Pengurus: Tambah / Edit / Hapus
 */
function simpanPengurus(item) {
  try {
    const sheet = getSheet('Pengurus');
    const isEdit = item.id ? true : false;

    if (isEdit) {
      const data = sheet.getDataRange().getValues();
      for (let i = 1; i < data.length; i++) {
        if (data[i][0] == item.id) {
          const row = i + 1;
          sheet.getRange(row, 2).setValue(item.nama || '');
          sheet.getRange(row, 3).setValue(item.jabatan || '');
          sheet.getRange(row, 4).setValue(item.foto || LOGO_BULAT);
          return { success: true, message: 'Data pengurus berhasil diperbarui!' };
        }
      }
      return { success: false, message: 'ID Pengurus tidak ditemukan.' };
    } else {
      const newId = getNextId(sheet);
      sheet.appendRow([
        newId,
        item.nama || '',
        item.jabatan || '',
        item.foto || LOGO_BULAT
      ]);
      return { success: true, message: 'Pengurus baru berhasil ditambahkan!' };
    }
  } catch (err) {
    Logger.log('Error simpanPengurus: ' + err);
    return { success: false, message: 'Gagal menyimpan pengurus: ' + err.toString() };
  }
}

function hapusPengurus(id) {
  try {
    const sheet = getSheet('Pengurus');
    const data = sheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (data[i][0] == id) {
        sheet.deleteRow(i + 1);
        return { success: true, message: 'Pengurus berhasil dihapus!' };
      }
    }
    return { success: false, message: 'ID Pengurus tidak ditemukan.' };
  } catch (err) {
    Logger.log('Error hapusPengurus: ' + err);
    return { success: false, message: 'Gagal menghapus pengurus: ' + err.toString() };
  }
}

/**
 * Kelola Pesan Masuk untuk Admin
 */
function getSemuaPesan() {
  try {
    const sheet = getSheet('Pesan');
    const data = sheet.getDataRange().getValues();
    if (data.length <= 1) return [];
    const result = [];
    for (let i = 1; i < data.length; i++) {
      if (!data[i][1] && !data[i][5]) continue;
      result.push({
        rowIndex: i + 1,
        timestamp: formatTanggal(data[i][0]) || data[i][0],
        nama: data[i][1] || '',
        email: data[i][2] || '',
        telepon: data[i][3] || '',
        subjek: data[i][4] || '',
        pesan: data[i][5] || ''
      });
    }
    return result.reverse();
  } catch (err) {
    Logger.log('Error getSemuaPesan: ' + err);
    return [];
  }
}

function hapusPesan(rowIndex) {
  try {
    const sheet = getSheet('Pesan');
    sheet.deleteRow(rowIndex);
    return { success: true, message: 'Pesan berhasil dihapus!' };
  } catch (err) {
    Logger.log('Error hapusPesan: ' + err);
    return { success: false, message: 'Gagal menghapus pesan: ' + err.toString() };
  }
}

/**
 * =====================================================
 * KELOLA SEMUA KONTEN HALAMAN WEB (PENGATURAN)
 * =====================================================
 */

function getDefaultKontenWeb() {
  return {
    brand_name: "YAYASAN BINA ASRI",
    brand_sub: "PROVINSI KALIMANTAN BARAT",
    logo_bulat: LOGO_BULAT,
    logo_persegi: LOGO_PERSEGI,
    top_address: "Jl. Raya Pontianak - Sei Raya Dalam, Kalimantan Barat",
    top_email: "info@binaasri.org",
    top_phone: "(0561) 789-0123 / 0812-5678-9012",
    wa_number: "6281256789012",
    hero_badge: "✨ Lembaga Sosial & Pendidikan Terpercaya di Kalimantan Barat",
    hero_title: "Yayasan Bina Asri Kalimantan Barat",
    hero_desc: "Mendedikasikan diri untuk membangun masyarakat yang mandiri, berdaya, dan sejahtera melalui santunan anak yatim dhuafa, bantuan sosial kemanusiaan, serta pemberdayaan ekonomi keluarga.",
    hero_cta_donasi: "🤝 Salurkan Donasi",
    hero_cta_program: "📋 Jelajahi Program",
    hero_cta_kontak: "💬 Hubungi Kami",
    stat_1_num: "12+",
    stat_1_label: "Tahun Mengabdi di Kalbar",
    stat_2_num: "1.250+",
    stat_2_label: "Anak Yatim Terbina",
    stat_3_num: "8.400+",
    stat_3_label: "Paket Sembako Disalurkan",
    stat_4_num: "100%",
    stat_4_label: "Amanah & Transparan",
    profil_tag: "Tentang Kami",
    profil_title: "Mewujudkan Harapan, Membangun Generasi Unggul",
    profil_img: "https://images.unsplash.com/photo-1542810634-71277d95dcbb?w=800",
    profil_legal: "Kemenkumham RI No. AHU-00123.AH.01.04",
    profil_p1: "Yayasan Bina Asri didirikan dengan niat luhur untuk menjadi wadah kepedulian sosial bagi masyarakat di seluruh pelosok Provinsi Kalimantan Barat. Kami bergerak secara aktif dalam menjembatani para donatur dan muhsinin dengan kaum dhuafa, anak-anak yatim piatu, serta keluarga pra-sejahtera yang memerlukan uluran tangan.",
    profil_p2: "Dengan semangat gotong royong dan akuntabilitas tinggi, setiap amanah program disalurkan langsung tepat sasaran untuk mewujudkan perubahan nyata yang berkelanjutan.",
    visi_title: "🎯 Visi Utama",
    visi_text: "Menjadi lembaga filantropi dan pendidikan terdepan di Kalimantan Barat yang profesional, amanah, dan berorientasi pada kemandirian umat.",
    misi_title: "🌟 Misi Utama",
    misi_items: "Menyelenggarakan beasiswa & pembinaan akhlak anak yatim.\nMeringankan beban sosial melalui bantuan berkala.\nMendorong kemandirian ekonomi keluarga pra-sejahtera.",
    program_tag: "Program Unggulan",
    program_title: "Program Kerja & Penyaluran",
    program_desc: "Inisiatif terstruktur kami untuk memajukan pendidikan, sosial kemanusiaan, dan kemandirian masyarakat dhuafa di Kalimantan Barat.",
    berita_tag: "Kabar Terkini",
    berita_title: "Berita & Dokumentasi Program",
    berita_desc: "Laporan berkala mengenai kegiatan aksi sosial, penyaluran bantuan, dan kabar terbaru dari Yayasan Bina Asri.",
    galeri_tag: "Dokumentasi",
    galeri_title: "Galeri Kegiatan Lapangan",
    galeri_desc: "Momen kebersamaan, senyum anak yatim, dan bukti nyata penyaluran program di lapangan.",
    pengurus_tag: "Amanah & Profesional",
    pengurus_title: "Susunan Pengurus Yayasan",
    pengurus_desc: "Para penggerak yang mendedikasikan waktu dan tenaga untuk menjaga transparansi dan amanah yayasan.",
    donasi_title: "Salurkan Infaq & Sedekah Terbaik Anda",
    donasi_desc: "Setiap rupiah yang Anda titipkan adalah lentera harapan bagi anak-anak yatim dan keluarga yang membutuhkan di tanah Kalimantan Barat. Mari bergandengan tangan menabur kebaikan.",
    donasi_points: "Laporan penyaluran transparan & berkala\nRekening atas nama resmi Yayasan (bukan perorangan)\nKonfirmasi donasi cepat melalui WhatsApp resmi\nDukungan donasi rutin maupun insidentil",
    donasi_banks: JSON.stringify([
      { id: 1, bank: "BANK KALBAR", badge: "Daerah", norek: "1025-00-123456", an: "a.n. YAYASAN BINA ASRI KALBAR" },
      { id: 2, bank: "BANK BRI", badge: "Nasional", norek: "0098-01-002345-50-8", an: "a.n. YAYASAN BINA ASRI" },
      { id: 3, bank: "BANK MANDIRI", badge: "Nasional", norek: "146-00-9876543-2", an: "a.n. YAYASAN BINA ASRI" },
      { id: 4, bank: "BANK SYARIAH (BSI)", badge: "Syariah", norek: "714-567-8901", an: "a.n. YAYASAN BINA ASRI" }
    ]),
    kontak_title: "Narahubung & Layanan",
    kontak_desc: "Pintu kami senantiasa terbuka untuk silaturahmi, konsultasi program, pendaftaran santri/yatim, maupun konfirmasi donasi.",
    kontak_alamat: "Jl. Raya Pontianak - Sei Raya Dalam No. 45, Pontianak, Kalimantan Barat 78124",
    kontak_telepon: "+62 812-5678-9012 / (0561) 789-0123",
    kontak_email: "sekretariat@binaasri.org / info@binaasri.org",
    kontak_jam: "Senin – Sabtu: 08.00 – 16.30 WIB",
    footer_desc: "Lembaga sosial dan pendidikan nirlaba yang berkhidmat untuk kesejahteraan masyarakat dan masa depan anak-anak dhuafa Kalimantan Barat.",
    footer_legal: "SK Kemenkumham RI: AHU-00123.AH.01.04 Tahun 2012\nNPWP: 03.123.456.7-701.000",
    footer_copyright: "Yayasan Bina Asri Provinsi Kalimantan Barat. Seluruh Hak Cipta Dilindungi."
  };
}

function getKontenSheet() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  let sheet = ss.getSheetByName('Pengaturan');
  if (!sheet) {
    sheet = ss.insertSheet('Pengaturan');
  }
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(['Key', 'Value']);
    sheet.getRange(1, 1, 1, 2)
      .setFontWeight('bold')
      .setBackground('#1B5E20')
      .setFontColor('#FFFFFF');
  }
  return sheet;
}

function getKontenWeb() {
  const defaults = getDefaultKontenWeb();
  try {
    const sheet = getKontenSheet();
    const data = sheet.getDataRange().getValues();
    if (data.length <= 1) {
      // Seed default data awal ke spreadsheet
      const rows = [];
      for (const k in defaults) {
        rows.push([k, defaults[k]]);
      }
      if (rows.length > 0) {
        sheet.getRange(2, 1, rows.length, 2).setValues(rows);
      }
      return defaults;
    }

    const result = { ...defaults };
    for (let i = 1; i < data.length; i++) {
      const key = (data[i][0] || '').toString().trim();
      const val = data[i][1];
      if (key) {
        result[key] = (val !== null && val !== undefined) ? val.toString() : '';
      }
    }
    return result;
  } catch (err) {
    Logger.log('Error getKontenWeb: ' + err);
    return defaults;
  }
}

function simpanKontenWeb(dataObj) {
  try {
    const sheet = getKontenSheet();
    const data = sheet.getDataRange().getValues();
    const map = {};
    for (let i = 1; i < data.length; i++) {
      const k = (data[i][0] || '').toString().trim();
      if (k) map[k] = i + 1;
    }

    for (const key in dataObj) {
      const val = dataObj[key];
      const valStr = typeof val === 'object' ? JSON.stringify(val) : String(val);
      if (map[key]) {
        sheet.getRange(map[key], 2).setValue(valStr);
      } else {
        sheet.appendRow([key, valStr]);
        map[key] = sheet.getLastRow();
      }
    }
    return { success: true, message: 'Konten halaman berhasil diperbarui dan disimpan!' };
  } catch (err) {
    Logger.log('Error simpanKontenWeb: ' + err);
    return { success: false, message: 'Gagal menyimpan konten: ' + err.toString() };
  }
}

/**
 * Ambil semua data sekaligus untuk update Admin Dashboard secara cepat
 */
function getAdminDashboardData() {
  return {
    kontenWeb: getKontenWeb(),
    berita: getBerita(),
    program: getProgram(),
    galeri: getGaleri(),
    pengurus: getPengurus(),
    pesan: getSemuaPesan()
  };
}

/**
 * =====================================================
 * SETUP AWAL DATABASE GOOGLE SHEETS
 * Jalankan SEKALI dari editor Google Apps Script
 * =====================================================
 */
function setupSheets() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);

  const setup = {
    'Berita'     : ['ID','Judul','Tanggal','Kategori','Ringkasan','Konten','Gambar'],
    'Program'    : ['ID','NamaProgram','Deskripsi','Target','Progress'],
    'Galeri'     : ['ID','Judul','LinkGambar'],
    'Pesan'      : ['Timestamp','Nama','Email','Telepon','Subjek','Pesan'],
    'Pengurus'   : ['ID','Nama','Jabatan','Foto'],
    'Admin'      : ['Username','Password','Nama','Role','TerakhirLogin'],
    'Pengaturan' : ['Key','Value']
  };

  for (const name in setup) {
    let sheet = ss.getSheetByName(name);
    if (!sheet) sheet = ss.insertSheet(name);
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(setup[name]);
      sheet.getRange(1, 1, 1, setup[name].length)
        .setFontWeight('bold')
        .setBackground('#1B5E20')
        .setFontColor('#FFFFFF');
    }
  }

  // Setup akun admin default jika belum ada
  const adm = ss.getSheetByName('Admin');
  if (adm.getLastRow() === 1) {
    adm.appendRow(['admin', 'admin123', 'Administrator Yayasan', 'Superadmin', '']);
  }

  // Contoh data pengurus
  const p = ss.getSheetByName('Pengurus');
  if (p.getLastRow() === 1) {
    p.appendRow([1, 'Bapak H. Ahmad Fauzi, S.Pd.', 'Ketua Yayasan', LOGO_BULAT]);
    p.appendRow([2, 'Ibu Hj. Siti Rahmawati, S.E.', 'Sekretaris Umum', LOGO_BULAT]);
    p.appendRow([3, 'Bapak Muhammad Arifin, M.M.', 'Bendahara Yayasan', LOGO_BULAT]);
    p.appendRow([4, 'Bapak Zulkifli, S.Sos.', 'Koordinator Lapangan', LOGO_BULAT]);
  }

  // Contoh data program
  const pr = ss.getSheetByName('Program');
  if (pr.getLastRow() === 1) {
    pr.appendRow([1, 'Beasiswa & Santunan Anak Yatim', 'Bantuan biaya sekolah, buku paket, dan bimbingan belajar intensif untuk anak-anak yatim piatu dhuafa di Kalimantan Barat.', '100 Anak', 75]);
    pr.appendRow([2, 'Bantuan Sembako & Pangan Dhuafa', 'Penyaluran paket kebutuhan pokok bergizi secara berkala untuk keluarga pra-sejahtera dan lansia.', '500 Keluarga', 60]);
    pr.appendRow([3, 'Layanan Medis & Khitanan Massal', 'Pemeriksaan kesehatan gratis, pengobatan keliling di pelosok desa, dan khitanan berkala.', '1.000 Penerima', 40]);
    pr.appendRow([4, 'Pemberdayaan Ekonomi UMKM Dhuafa', 'Pelatihan wirausaha, bantuan modal usaha mikro, dan pembinaan berkala bagi ibu-ibu rumah tangga.', '50 Pelaku Usaha', 50]);
  }

  // Contoh data berita
  const b = ss.getSheetByName('Berita');
  if (b.getLastRow() === 1) {
    b.appendRow([
      1,
      'Yayasan Bina Asri Salurkan Bantuan Sembako di Pontianak Timur',
      new Date(),
      'Sosial',
      'Sebanyak 250 paket sembako disalurkan kepada warga prasejahtera dan kaum dhuafa.',
      'Pontianak — Yayasan Bina Asri Provinsi Kalimantan Barat kembali melaksanakan aksi kemanusiaan berupa penyaluran 250 paket sembako bagi masyarakat pra-sejahtera di Pontianak Timur.\n\nKegiatan ini dipimpin langsung oleh Ketua Yayasan bersama jajaran relawan. Warga menyambut kegiatan dengan antusias dan rasa syukur yang mendalam.\n\nKetua Yayasan menyampaikan bahwa program ini merupakan wujud nyata kepedulian para donatur untuk membantu meringankan beban saudara-saudara kita yang membutuhkan. Yayasan berkomitmen untuk terus memperluas jangkauan ke kabupaten/kota lainnya di Kalimantan Barat.',
      'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=800'
    ]);
    b.appendRow([
      2,
      'Pendaftaran Beasiswa Santri & Pelajar Berprestasi Resmi Dibuka',
      new Date(),
      'Pendidikan',
      'Program beasiswa pendidikan tahun ajaran baru kini terbuka untuk jenjang SD, SMP, hingga SMA.',
      'Yayasan Bina Asri resmi membuka pendaftaran program beasiswa pendidikan bagi putra-putri dhuafa berprestasi di Kalimantan Barat.\n\nFasilitas beasiswa mencakup pembebasan biaya perlengkapan sekolah, seragam, uang saku bulanan, serta program pendampingan akhlak dan keterampilan.\n\nPendaftaran dapat dilakukan langsung di kantor sekretariat Yayasan atau melalui narahubung resmi kami.',
      'https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800'
    ]);
    b.appendRow([
      3,
      'Pelatihan Menjahit & Kerajinan Tangan untuk Pemberdayaan Ibu-Ibu',
      new Date(),
      'Pemberdayaan',
      'Meningkatkan kemandirian ekonomi keluarga melalui pelatihan kerajinan tenun dan jahit.',
      'Dalam rangka mencetak keluarga mandiri, Yayasan Bina Asri mengadakan workshop keterampilan menjahit dan pembuatan souvenir khas Kalimantan Barat.\n\nKegiatan ini diikuti oleh 30 peserta ibu rumah tangga dan berlangsung selama 2 pekan dengan bimbingan instruktur profesional.',
      'https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?w=800'
    ]);
  }

  // Contoh data galeri
  const g = ss.getSheetByName('Galeri');
  if (g.getLastRow() === 1) {
    g.appendRow([1, 'Penyaluran Paket Sembako Ramadhan', 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=800']);
    g.appendRow([2, 'Pemberian Beasiswa Anak Yatim', 'https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800']);
    g.appendRow([3, 'Pelatihan Kerajinan UMKM Binaan', 'https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?w=800']);
    g.appendRow([4, 'Pemeriksaan Kesehatan Warga Pelosok', 'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?w=800']);
    g.appendRow([5, 'Pembagian Al-Quran & Kitab Pelajar', 'https://images.unsplash.com/photo-1542810634-71277d95dcbb?w=800']);
    g.appendRow([6, 'Kegiatan Gotong Royong Lingkungan', 'https://images.unsplash.com/photo-1593113598332-cd288d649433?w=800']);
  }

  Logger.log('Setup selesai dengan sempurna!');
  return 'Setup semua sheet dan sistem admin selesai!';
}